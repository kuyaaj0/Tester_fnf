Store scripts used in different stages, such as "states", "substates", "globals" and so on

Only applicable to "global-mod" and "top-mod"
Script for storing and adding settings options to save your mod data.

Only support hscript(ext: ".hx")
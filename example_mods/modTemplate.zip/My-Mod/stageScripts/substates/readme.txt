To use "HScriptSubstate" Class
You just need to create a folder and add the script(only support ext "hx") inside
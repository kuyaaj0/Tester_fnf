Stores scripts(only support ext "hx") that will be applied globally to the game

It will only load once at the beginning of the game, and if you need to reload the script, you must reload the mod(reset game)
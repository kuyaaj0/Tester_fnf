Here are scripts(only support ext ".hxc" and ".hxs") that use custom classes

Similar to V-Slice, where the inherited classes will have different purposes (or destinations)

It will only load once at the beginning of the game, and if you need to reload the script, you must reload the mod(reset game)

If you want to use it in other scripts, you can use "import", pay attention to package and className
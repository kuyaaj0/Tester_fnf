Put your video here!
The best file ext is "mp4"
and the resolution is 1280x720